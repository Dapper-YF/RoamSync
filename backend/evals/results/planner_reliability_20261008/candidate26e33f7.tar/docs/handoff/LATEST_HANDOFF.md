# RoamSync Handoff

## Snapshot

2026-10-08. Goal ACTIVE. Provider health and unchanged-release initial Candidate PASSED; full lifecycle BLOCKED by confirmed day2 intent parser defect. Human approved the exact six-path candidate branch/commit scope; production not authorized.

## Current Freeze / Rehearsal Status

Application8ee7dbf/documentation0b5010fe unchanged. Clean source e7e22849869443bb73f96bce736fb86a1c4b3745f2a48f6f32da3273176622a6;366 hashes/175 API+Worker source files exact; built Nginx3001/API8001/isolatedPG17, no source mounts. Independent approved candidate branch records only six reviewed existing paths; original release retained.

## Latest shadow-mode evidence

MEASURED fixed6 real GLM calls,0retry,serial:6/6completed/stop, two strict Research calls17.313/23.214s, connection reuse passes. JSON and transport are separate categories; historical raw/finish reason missing, exact original roots UNLOCATED. No guessed source/config fix. Real timeout probe maps ConnectTimeout→planner_timeout.

## Prior milestone baseline (before shadow split)

New normal browser Nanjing3days candidate has8activities, valid=true,pending Revision; formalactivities0/version1. Three older failed Runs retained. Productionfc3 remains; no production/database/main/image replacement. Earlier dirty-tree full lifecycle is historical, not new clean-ref proof.

## Prior verification

Release locked Linux full854/Web125/typecheck/build remains. New independent patch changes only planning_intent_service.py and test_planning_intents.py: nine source lines classify exact plan-property forms after real activity matches, unknown named venues still clarify. Four regressions red→green; patched full858/0fail/error/skip,2warnings on emptyPG17. Initial wrong test launch flags97missing-map-key failures retained; corrected run uses existing compose.test.yaml flags. Real E2E config unchanged. Proposed source6d0257506c8ae65cbfc640cbdbfd3376b23bac2cf9623306432513f48ddca1eb.

## Prior blockers (historical)

Current concrete blocker: day2 request's “整体三天…框架”/“其他日期不变” misread as activities; same Run remains awaiting_clarification after a normal supplemental answer. Candidate not accepted. Execution/Disruption/Recovery/reject/Explanation downstream unverified. Graph/Validator/time/budget/route/approval unchanged. No Mock/cleared failures/lowered assertion.

## Interview framing

Patch: backend/evals/results/planner_reliability_20261008/proposed_intent_meta_fix.patch; report and XML/manifests alongside. New proposed branch codex/roamsync-planner-reliability-20261008 from0b5010fe; exact2code/test+4existing report paths. Current human explicitly approved this six-path candidate branch and commits. Form approved new clean candidate; repeat required provider/full real lifecycle/runtime bindings. Original Release preserved. No production deployment or DB changes; final online approval only after all gates pass. Goal ACTIVE/NOT READY.
