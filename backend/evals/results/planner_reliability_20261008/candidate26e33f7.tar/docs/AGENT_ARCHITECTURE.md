# RoamSync Agent v1 architecture contract

Contract version: `agent-v1.0` + `travel-goal-phase0` + `travel-companion-phase1/2` (2026-09-29)

Status: frozen development baseline

Effective date: 2026-09-03

This document is the source of truth for the first Agent planning workflow. It
describes the behavior that is implemented and tested before a real provider is
enabled. Product ideas that are not part of the current graph are labelled as
deferred and must not be presented as implemented Agent behavior.

## Scope and product boundary

### Travel Goal boundary (2026-09-29)

Never escalate a conversational, exploratory, informational, recommendation,
comparison, or explanation request into an itinerary mutation without explicit
user intent.

`TravelGoalRouting` in `schemas.py` precedes `AssistantRouter` tool selection.
It carries goal_type, confidence, target_runtime, mutation_requested,
trip_context_required, knowledge_required, live_fact_likely_required,
referenced_entities, referenced_previous_decision, clarification_needed, and
short signals. Runtime/goal consistency and non-planning mutation prohibition
are schema invariants. Confidence values are rule priorities, not calibrated
model probabilities; referenced_entities are mentions, not resolved IDs.

- Companion: independent `CompanionRuntime` / LangGraph with bounded typed
  `CompanionContext`, `CompanionDraft` and `CompanionResult`, then an early
  session-only return before Planning-heavy reads.
  No tool router, PlanningRun, Revision, formal itinerary or execution writes.
  Context must not invoke Planning's missing-preference repair path.
- Planning: existing bounded tool router, creation preview/confirmation,
  Planning Intent and unchanged worker/graph/validator/Revision lifecycle.
- Execution: recognize dwell/departure intent and direct the user to existing
  deterministic activity controls. Chat itself executes no command.

Suggestion is a structured conversation proposal with a server-owned identity.
Planning Decision is a validated candidate.
Formal Mutation requires the existing explicit approval and transactional
acceptance (or existing deterministic/manual APIs). None of these authorities
is conferred by a Companion response, its confidence or its entity mentions.

`create_planning_run` also rejects clear Companion/Execution requests before
intent/model extraction and rejects answer-only policy routes before INSERT.
Unknown low-confidence direct planning submissions retain the existing intent
policy/clarification gate; they do not become authorized via Companion. Internal
structured disruption/experience recovery remains governed by persisted facts.

Compatibility: assistant top-level response fields are unchanged. Optional
`messages[].goal_routing`, `companion_result` and `planning_brief` use the existing
JSON conversation column; no database migration. Existing answered/queued question runs and checkpoints remain readable
and executable through the historical graph path. New question submissions to
the planning API now return 422 (`route=companion`) and should use assistant
messages. Existing creation previews, clarification interrupts and explicit
accept/reject contracts remain unchanged. Web supports optional metadata;
Android ignores unknown DTO fields and displays a nullable-run reply directly.

Phase 1 provides durable structured suggestions and an explicit PlanningBrief
adapter. Phase 2 registers selective Tourism Knowledge retrieval; no live Fact Resolver or long-term preference
learning. Phase 0 history is in `agent/TRAVEL_GOAL_ROUTING_PHASE0_20260929.md`;
current acceptance evidence is in `agent/TRAVEL_COMPANION_PHASE1_20260929.md`.

### Pre-trip conversation reset (2026-09-30)

`POST /api/v1/assistant/sessions/{session_id}/reset` locks the session and
allows reset only while `trip_id` is null. It deletes the discarded session
and creates an empty session with a new identity in one transaction, removing
messages, structured Companion state, pending creation previews and retry IDs.
Requests against the discarded identity fail; saved trip sessions are rejected
by the existing AssistantToolError boundary. It creates no Trip, PlanningRun or
Revision and changes no formal itinerary. No schema migration is required.
The Web button is available before trip creation and disabled during requests;
failed resets retain the visible history and draft. Creating a trip still
carries the current discussion into that trip's saved conversation.

### Independent Companion boundary (2026-09-29)

2026-09-30 conversation policy: ordinary stable conversation (including culture,
history, recommendations, comparison, photography and local life) uses a bounded
CompanionDraft with a complete natural response_text and separate durable
suggestions. It does not require coverage by the seven-document corpus. Explicit
source/verification requests retain the reviewed-assertion retrieval path;
live facts and original decision rationale retain their server-owned boundaries.
General answers carry model_general_knowledge_unverified metadata, never verified
citations. Structured suggestions are not appended again to the final reply.
Evidence IDs, claim classifications and corpus gaps stay in structured metadata;
Web shows answer basis and source links in a closed-by-default Thinking disclosure,
without exposing hidden model reasoning. No migration, new node/tool permission,
Planning authority or formal mutation change is required. Existing persisted
diagnostic replies remain readable with presentation cleanup. Acceptance tests:
test_companion_conversation_policy.py, explicit-source knowledge tests and
CompanionThinking.test.tsx; isolated PostgreSQL suite required.

`companion_contracts.py` is the Companion-owned schema authority. Its model
draft excludes identity, interaction authorization, original rationale and
handoff fields. The fixed sibling graph interprets goal, resolves saved state,
determines InformationNeed, gathers only needed read context/tool evidence,
generates, extracts interaction outcome and prepares conversation persistence.
It rejects Planning/Execution goals. The assistant service owns the atomic JSON
commit; a graph trace never claims that a database commit already occurred.

CompanionContext is not PlanningContext. SELECTs disable ORM autoflush and never
repair missing preferences. History/culture requests read no PlanningRun,
execution or full itinerary. Formal-decision explanations may load a scoped
identity/name/date/time itinerary summary and a targeted accepted decision
summary. No routes, checkpoints, lock/validator state or execution facts are
passed through this context. Recent model prose is limited to 12 turns; typed
state is reconstructed from durable JSON, with bounded relevant projections.
Automatic conversation summary generation remains deferred.

Suggestion IDs are deterministic UUID5 values over session/turn/batch index,
independent of place/Activity identity. Resolve explicit saved refs, latest-batch
ordinals, unique exact titles or single-focus pronouns; unknown/ambiguous refs
require clarification. Raw factual/schedule subjects cannot acquire Suggestion
authority from coincident display names. Suggested/discussed/user_liked,
user_confirmed and must_do remain distinct. Conversation preference statements
retain user source turns and never write TripPreferences or long-term Memory.

PlanningBrief is created only by the explicit Planning adapter when the Router
authorizes mutation. CompanionResult cannot contain a non-null handoff. The
adapter persists correct Suggestion/source refs, raw user dates/party/budget,
supported duration, candidate interests and explicit must-do requirements.
Ambiguous new structured refs stop before tool selection or Run creation.
The Brief is bounded ToolRouter input, not formal state, a Revision or a new
PlanningContext hard constraint. Suggestion/raw mentions cannot be used as
activity_N/candidate_N or database identity. Legacy answered-Run prose may retain
its prior explicit Planning continuation only without Phase 1 structured
history and without an invented grounded Brief. Existing creation previews,
worker/Graph/resolver/route/validator/approval/recovery lifecycles remain.

Original saved Suggestion explanations require its persisted originating turn
and reasons. Original formal-decision explanations additionally require an
accepted Run/Revision for the current formal version, validated decision summary
without errors, exact surviving target Activity, validated entry and matching
scheduled time. Invalid/unavailable/stale/ambiguous records yield
rationale_unavailable. These are saved validated reason labels, not hidden model
reasoning; shadow Ledger and Stage 2.2 remain OPEN. Current reconstructed
explanations cannot claim prior-decision provenance and are not generated by
this phase's runtime.

InformationNeed selects KnowledgeToolPort only for needed stable knowledge.
Casual food questions use a separate bounded general-knowledge model reply. This
path does not query the reviewed corpus or claim source verification; its
`grounding_limitations` records `model_general_knowledge_unverified`. Requests
for sources, live operating facts, and saved planning rationale retain their
existing evidence and authority boundaries.
The Phase 1 default port was absent; Phase 2 registers the reviewed-corpus adapter.
Retrieval availability requires bounded uniquely
referenced evidence with source/type/scope. Draft evidence refs must exist in
that supplied set. Missing history/culture evidence degrades explicitly; other
proposals are marked unverified. Missing live facts bypass the model and return
server-owned unavailable output; stable knowledge cannot fill today's fact gap.
knowledge_supported denotes known supplied citations, not an independent factual
entailment guarantee. Phase 2 integrates the parallel Tourism Knowledge implementation
through its public request/result adapter, retaining the independent graph.

MEASURED acceptance: fresh Linux/PostgreSQL 405 passed before edits; final 429
passed, 2 existing warnings, 49.69s. Web 101 plus typecheck/build; Android 35;
offline runtime 21/21 (fake calls 3, real calls 0); routing 60/60, Error A/B zero.
These Phase 1 historical results predate Phase 2. Actual SQL integration tests establish mutation/context boundaries; no-DB eval
does not. No migration, live model quality gate, deployment or Demo rehearsal
completion is claimed. See the Phase 1 report and
`../backend/evals/results/companion_phase1/` for recorded evidence.

### Tourism Knowledge integration boundary (2026-09-29)

Only the add-file diff of implementation commit 5023a28 is applied; its snapshot
parent 0fab288 is not merged. The Phase A core remains unchanged.
`companion_information.py` chooses the existing seven knowledge types and
explicit destination/audience/season filters. Metadata is not inferred inside
retrieval. Thank-you/liked turns, explicit Planning and original-rationale
questions require no knowledge call. Weather/operational/execution facts and
explicit timing conditions require live evidence and cannot use stable RAG.

`tourism_knowledge_adapter.py` maps only public contracts. Graph/Runtime depend
on KnowledgeToolPort, not repository/ranking internals. Composition lazily
ingests seven reviewed short documents from four official/institutional pages
into an in-memory repository. Lexical BM25 is the registered retrieval mode,
fixtures are excluded, query/filter/source/expiry/identity bounds are checked.
There is no production persistence, embedding provider or runtime crawling.

Evidence carries knowledge refs, document/chunk IDs, source URL/name/authority,
review times, stable/semi-stable scope and corpus-scoped place references.
Source applicability distinguishes general strategy from destination-specific
themes; unspecified applicability cannot claim factual completeness. Retriever
outcomes distinguish no_results, unavailable, unsupported, insufficient and
live/decision boundaries. Contradictory outcome/advisory contracts fail closed.
Restrictive advisory never becomes answer authority merely because hits exist.

AssistantSession stores additive knowledge_evidence, answer_evidence_refs,
retrieval summary, grounding_status and grounding_limitations. Draft citation
refs and visible knowledge_ refs must be a subset of supplied refs. Invalid
refs reject the turn; absent citations cannot publish a grounded factual answer.
citations_validated / knowledge_supported mean membership validation only,
not claim entailment. A controlled valid-citation/unsupported-claim bad case is
retained. A measured broad parent-suitability claim from general guidance has a
narrow server guard and prompt restriction; this is not full sentence validation.

Knowledge cannot explain an original Planning decision. Saved Suggestion
reasons retain their originating evidence; formal rationale keeps the accepted
version/validated target/time fences. Tourism corpus place IDs cannot become
Activity/Planning short refs. Planning ToolRouter receives explicit Brief plus
ordinary conversation history; raw Companion/corpus metadata is excluded there.
Planning Graph, strict resolver, validator, approval and deterministic Execution
sources remain unchanged. No migration is required; Web metadata is optional
and Android continues ignoreUnknownKeys.

Acceptance and the separate deterministic/retrieval/live model evidence are in
`agent/TRAVEL_COMPANION_PHASE2_20260929.md` and
`../backend/evals/results/companion_phase2/`. Demo NOT READY and Decision Ledger
Stage 2.2 OPEN are unchanged; live knowledge quality is not a Demo exit gate.

Agent v1 covers deterministic context parsing, structured semantic extraction,
database entity grounding, risk/workflow routing, bounded clarification, itinerary drafting,
route enrichment, deterministic validation, one correction attempt, candidate
revision persistence, and explicit approval or rejection.

The Agent produces a reviewable `PlanRevision`; it never writes a formal trip
directly. Formal `Activity` and `RouteLeg` rows are changed only by the
transactional revision-acceptance service after deterministic validation and an
explicit user decision.

Agent v1 is a local, single-user development baseline. Authentication and tenant
authorization are not implemented. The API must not be exposed as a public or
multi-user service until those boundaries are added and tested.

## Implemented and deferred components

| Component | V1 status | May do | Must not do |
| --- | --- | --- | --- |
| Rules/context parser | Implemented | Normalize explicit dates, relative dates and UI-selected entities | Expand regexes into an unrestricted natural-language interpreter |
| Structured semantic parser | Implemented with configured provider fallback | Return a schema-validated multi-operation `SemanticIntentDraft` | Authorize execution, invent IDs, or write data |
| Entity grounding | Implemented | Bind days, activities and existing place candidates to trip-owned IDs | Guess between duplicate or missing entities |
| Policy/risk gate | Implemented | Route to answer, clarification, preview, or rejection and require approval for changes | Treat model output as user authorization |
| Research Agent | Deferred | Future: query configured providers and persist verified candidates and sources | It is not a node in the current graph and must not be implied to have run |
| Draft provider / Planner | Implemented | Select supplied place IDs and dates into a strict draft | Query the database, invent places, costs, sources, routes, or approval |
| Route enrichment | Implemented | Resolve every adjacent route through the configured map adapter | Hide provider failures or silently fabricate production routes |
| Deterministic validator | Implemented | Enforce ownership, dates, time, route, budget, source, protected-activity, and version rules | Delegate hard-constraint decisions to a model |
| Reviewer correction | Implemented as one bounded re-draft | Feed validation errors and the previous plan back to the draft provider once | Override validation, loop without a bound, or approve a revision |
| Orchestrator | Implemented | Route, checkpoint, interrupt, resume, and record outcomes | Make unconstrained product decisions |
| Acceptance service | Implemented | Revalidate and atomically apply a current approved revision | Accept stale, invalid, rejected, or superseded revisions |

The `researching` run status currently covers planning-context assembly and
intent resolution. It does not mean that a Research Agent or live Web Search ran.

## Authoritative contracts

The Pydantic definitions in `backend/app/schemas.py` are authoritative:

- `PlanningIntentParseRequest`: normalized non-blank message plus optional UI
  context.
- `SemanticIntentDraft`, `GroundedIntent`, and `IntentPolicyDecision`: strict
  semantic, entity-binding, and workflow-policy layers carried by
  `PlanningIntentResolution`.
- `PlanningIntent` and `PlanningRequest`: backward-compatible planning fields
  consumed by the current Planner prompt.
- `PlanningRunCreate`: `initial_plan` or `replan` plus a required, non-blank
  request of at most 4,000 characters.
- Formal `Activity` responses carry the user-authored `importance` decision
  semantic (`low`, `normal`, `high`, or `must_do`). It is supplied to the
  Planner as a soft preference; deterministic sacrifice constraints are added
  only with the corresponding Phase 2 validator slice.
- `CandidatePlanSnapshot`: at most 100 unique candidate activities and at most
  200 uniquely positioned route legs.
- `PlanningClarificationInterrupt`: `kind`, one or more questions, and `run_id`.
- `PlanningApprovalInterrupt`: `kind`, `run_id`, and `revision_id`.
- `PlanningRunDecision`: only `clarify`, `accept`, or `reject`; clarification
  requires a non-blank answer.
- `PlanValidationResult`: hard errors and non-blocking warnings.

Unknown fields are forbidden on intent and interrupt inputs. The semantic parser
emits no operation mode or database identifiers. Its output must pass
deterministic grounding and the policy gate before the graph may plan. The legacy
four-value `PlanningIntent` vocabulary remains only as a compatibility field;
workflow routing uses the structured operation list and policy decision.

## Persisted records and ownership

| Record | Owner | Purpose |
| --- | --- | --- |
| `Trip`, `DayPlan`, `Activity`, `RouteLeg` | Business services | Formal user-visible state |
| `PlaceCandidate`, `SourceRecord` | Research/import services | Trip-owned facts available to planning |
| `PlanningRun` | Orchestrator/repository | Lifecycle, base trip version, provider metadata, usage, failure, and pending interrupt |
| `PlanRevision` | Planning repository | Immutable before/proposed snapshots, validation result, sources, and decision |
| `CandidateRouteLeg` | Route enrichment/repository | Auditable route evidence tied to a revision |
| LangGraph checkpoints | LangGraph runtime | Recoverable execution state, keyed by `PlanningRun.id` as `thread_id` |

`PlanningRun`, `PlanRevision`, and candidate evidence are the product and audit
source of truth. LangGraph checkpoints are execution infrastructure and must not
replace product records.

## Graph state and serialization boundary

`PlanningGraphState` may contain only JSON-serializable values:

| Field | Producer | Consumer |
| --- | --- | --- |
| `run_id`, `trip_id`, `user_request` | Runtime | All nodes |
| `entry_point`, `selected_day_id`, `selected_activity_id` | Persisted `PlanningRun` UI context | Intent resolver and grounding |
| `planning_context` | `resolve_intent` | Planner and revision persistence; includes structured goals, persisted formal route facts and selected `decision_context` |
| `intent_resolution` | `resolve_intent` | Router and Planner |
| `planning_goals` | `resolve_intent` | Planner, Goal Satisfaction Check, and revision persistence |
| `clarification_count` | Runtime / `clarify` | Two-round clarification bound |
| `proposed_snapshot` | `plan`, then `validate` after route enrichment | Validator and persistence |
| `validation_result` | `validate` | Conditional router and correction prompt |
| `review_count` | `review` | Single-correction bound |
| `goal_satisfaction` | `goal_check` | Goal repair router and revision persistence |
| `goal_review_count`, `goal_feedback` | `goal_repair` | One bounded repair for unmet hard goals |
| `revision_id` | `persist` | Approval and acceptance |
| `outcome` | `accept` or `reject` | Terminal result |

Database sessions, ORM entities, API clients, secrets, and executable objects are
forbidden in graph state. The public run-creation API persists UI selection
context and rejects selected day/activity IDs that do not belong to the trip.

## State machine

```text
queued
  -> researching
  -> awaiting_clarification -> researching       (at most two answers)
  -> planning
  -> validating
       -> planning                               (one correction only)
       -> awaiting_confirmation
  -> goal_check
       -> planning                               (at most one hard-goal repair)
       -> awaiting_confirmation
  -> accepted | rejected | failed
```

The implemented graph nodes are:

```text
START -> resolve_intent -> clarify? -> plan -> validate
      -> review? -> plan -> validate -> goal_check
      -> goal_repair? -> plan -> validate -> goal_check -> persist -> approval
      -> accept | reject -> END
```

`cancelled` is a reserved persisted status; Agent v1 exposes no cancellation
transition. A second validation failure terminates the run with
`planner_constraints_unsatisfied` and creates no pending revision. A valid
candidate that still misses an explicit deterministic hard Planning Goal is
given one structured repair attempt; a second miss terminates with
`goal_constraints_unsatisfied`. Soft goals are observations only and never
block a revision.

Human clarification and final approval use explicit interrupts. Side effects
before an interrupt must be idempotent. Resuming with the wrong decision kind or
resuming a terminal run is rejected.

## Candidate evidence and hard validation

Every candidate activity must reference a trip-owned `PlaceCandidate` and its
trip-owned `SourceRecord`. Costs are copied from backend records, never trusted
from the model. Every adjacent pair in the complete candidate day, including
formal locked, active, or completed activities that remain in place, must have a
`CandidateRouteLeg`.

Acceptance re-runs validation while locking the revision, run, and trip. At
minimum, these conditions block acceptance:

- unknown or cross-trip place/source/replacement IDs;
- date outside the trip or daily time window;
- overlapping activities or insufficient route time;
- changed locked, active, or completed activities;
- omitted or changed activities outside the grounded day/activity scope;
- new activities outside a grounded target day;
- increased estimated cost when the grounded constraint forbids an increase;
- daily or total budget violation when a Trip budget limit is configured;
- missing or structurally inconsistent route evidence;
- formal trip version different from `base_trip_version`;
- revision or run no longer pending confirmation.

Rejecting a candidate changes only the run and revision decision records. It
must not change formal activities, routes, or the trip version.

## Provider and tool policy

### Draft provider

- Production configuration is injected through `Settings`; secrets never enter
  graph state, prompts, responses, or database snapshots.
- The Responses API is called with JSON Schema output and `store=false`.
- Provider timeout and SDK retry count are bounded by
  `PLANNER_TIMEOUT_SECONDS` and `PLANNER_MAX_RETRIES`. The outer planning
  execution also has an `AGENT_RUN_TIMEOUT_SECONDS` wall-clock deadline; an
  expiry marks the run failed as `planning_run_timeout` and releases its worker.
- Agent workers claim up to `AGENT_WORKER_CONCURRENCY` independent runs at once
  (default 2), so one slow provider call cannot block the whole queue.
- The model may choose only supplied place IDs and trip dates. Backend code
  resolves costs, sources, replacement IDs, and routes.
- Candidate names, descriptions, tags, and user text are untrusted data, not
  instructions.

### Semantic intent provider

- High-confidence dates and UI references are resolved by deterministic code.
- Requests left as legacy `unknown` use the configured DeepSeek/OpenAI-compatible
  Responses endpoint with the `SemanticIntentDraft` JSON Schema.
- The provider extracts semantic operations and mentions only. Backend grounding
  owns IDs, completeness, risk, confirmation, and workflow routing.

### Map provider

- Production requires `AMAP_REST_KEY`.
- `ALLOW_MAP_ESTIMATES=true` is permitted only for tests and explicit local
  development. It is not a silent production fallback.
- Provider rejection, credentials failure, quota exhaustion, network failure,
  and missing configuration remain visible as stable failures.

### Deferred tools

Weather, Web Search, OCR/multimodal import, and community-content extraction are
outside Agent v1. They require separate input/output, source, timeout, retry,
cache, privacy, and failure contracts before becoming graph nodes.

## Stable planning failure codes

| Code | Meaning | Retry policy |
| --- | --- | --- |
| `planner_not_configured` | Key or model missing | Configuration change required |
| `planner_authentication_failed` | Credentials rejected | Do not retry unchanged credentials |
| `planner_permission_denied` | Model/account permission denied | Do not retry unchanged configuration |
| `planner_rate_limited` | Provider quota or rate limit | SDK may retry within configured bound |
| `planner_timeout` | Provider timeout | SDK may retry within configured bound |
| `planner_unavailable` | Connection failure | SDK may retry within configured bound |
| `planner_incomplete_output` | Incomplete or filtered output | Fail the run |
| `planner_invalid_output` | Schema or ownership violation | Fail the run; do not coerce |
| `planner_provider_error` | Provider 5xx response | SDK may retry within configured bound |
| `planner_request_rejected` | Provider 4xx response | Do not retry unchanged request |
| `planner_constraints_unsatisfied` | Second deterministic validation failed | Fail with validation codes; no revision |
| `goal_constraints_unsatisfied` | A valid candidate still misses a hard goal after one repair | Fail with structured goal evidence; no revision |
| `decision_context_invalid` | Planner precondition has contradictory or dangling facts | Fail before model invocation with invariant codes |
| `planning_run_timeout` | The end-to-end worker deadline expired | Fail visibly and release the worker; retry as a new run after resolving provider latency |
| `planning_graph_failed` | Unexpected runtime failure | Preserve sanitized diagnostic text and investigate |

Failure messages returned or logged must not contain API keys, authorization
headers, raw private trip payloads, or full provider responses.

## API boundary

Agent v1 uses these endpoints:

| Method and path | Purpose |
| --- | --- |
| `GET /api/v1/trips/{trip_id}/planning-context` | Read the normalized, read-only planning input |
| `POST /api/v1/trips/{trip_id}/planning-intent/resolve` | Preview strict intent resolution |
| `POST /api/v1/trips/{trip_id}/planning-runs` | Queue a non-blank planning request |
| `GET /api/v1/trips/{trip_id}/planning-runs` | List recent runs, bounded by `limit` |
| `GET /api/v1/planning-runs/{run_id}` | Read lifecycle, failure, and interrupt state |
| `GET /api/v1/planning-runs/{run_id}/revision` | Read the latest candidate revision |
| `POST /api/v1/planning-runs/{run_id}/decision` | Resume clarification or final approval |

The direct revision accept/reject endpoints exist for deterministic service and
test use. Product UI approval should use the run decision endpoint so LangGraph
checkpoint state and persisted run state advance together.

## Agent v1 acceptance gate

All hard gates must pass at 100%; aggregate model quality is not allowed to hide
a safety failure.

| Gate | Required result | Evidence |
| --- | --- | --- |
| Structured intent | Compound requests retain all operations and constraints | `test_planning_intents.py` |
| Grounding and policy | UI context is trip-owned; ambiguity routes to clarification; writes only produce previews | `test_planning_intents.py`, `test_planning_runs.py` |
| Scope enforcement | A candidate cannot change state outside grounded day/activity scope | `test_planning_runs.py` |
| Non-blank run | Missing or whitespace-only request is rejected with 422 | `test_planning_runs.py` |
| Structured output | Extra/unknown data and non-supplied IDs are rejected | `test_openai_planner.py`, `test_planning_runs.py` |
| Prompt-data isolation | Provider instructions declare user and candidate text untrusted | `openai_planner.py`, provider tests |
| Protected state | Locked, active, and completed activities cannot be changed | `test_planning_runs.py` |
| Evidence integrity | Place, source, route, date, time, and budget constraints are deterministic | `test_planning_runs.py`, `test_planner.py` |
| Bounded correction | Exactly one correction is permitted; a second failure creates no revision | `test_planning_graph.py` |
| Goal-aware planning | Explicit goals reach the Planner; hard goals are checked after validation with one bounded repair | `test_planning_goals.py`, `test_openai_planner.py` |
| Decision Context | Target-day formal route/execution facts are selected with provenance; protected and editable activities are disjoint | `test_decision_context.py`, `test_openai_planner.py` |
| Human approval | No candidate becomes formal state before acceptance | `test_planning_graph.py`, `test_planning_runs.py` |
| Safe rejection | Rejection leaves the formal plan unchanged | `test_planning_graph.py` |
| Stale-write protection | A changed trip version prevents acceptance | `test_planning_runs.py` |
| Recovery | A PostgreSQL checkpoint resumes through a new connection | `test_planning_graph.py` |
| Provider failures | Missing config, timeout, invalid ID, and correction input have stable behavior | `test_openai_planner.py`, `test_planning_graph.py` |
| Isolated persistence | Migrations and the complete backend suite pass against the test PostgreSQL service | `compose.test.yaml` |

Before a real-provider milestone is accepted, run one non-private test trip with
real Planner and map credentials and record: provider/model, request ID if
available, token usage, elapsed time, route provenance, validation result, and
the approval/rejection outcome. Never commit the credentials or private payload.

The repeatable intent benchmark is `python -m evals.run_intent_eval`; add
`--use-model` to require the configured semantic provider. Provider connectivity
is checked separately with `python -m evals.run_provider_smoke`. A model-enabled
evaluation exits non-zero when any model call falls back, even if deterministic
rules still produce the expected route.

## Decision Ledger validation responsibility (2026-09-27)

The Planner still emits `decision_ledger` and the deterministic Ledger validator
always runs after route enrichment, optional time-only route repair, and the
candidate itinerary validator. Its result is **not** an itinerary-safety verdict.
`CandidatePlanSnapshot.provenance_parse_errors` contains only sanitized error
codes when a provenance field cannot be parsed; place IDs, dates, times, route
fields and other candidate fields still use strict parsing.

`DECISION_LEDGER_VALIDATION_MODE=shadow` is the production/demo default. In
`shadow`, an invalid Ledger is persisted as `decision_summary.status=invalid`,
with `decision_ledger_status` and sanitized `decision_ledger_errors` in the
revision difference summary and trace, but does not mutate candidate validity.
`enforced` preserves a blocking Ledger gate for Stage 2.2 evaluation. A valid
candidate still must pass the independent itinerary/semantics validator and
hard Goal check before a pending Revision is saved. Acceptance revalidates
formal-state safety and stale version constraints; neither mode auto-applies a
Revision. Invalid/unavailable provenance never authorizes the UI to show model
explanation or activity reasons. Stage 2.2 Decision Ledger MVP remains OPEN.

An unknown/unallowed place is a hard candidate parse/validation failure.
`unsupported_addition` means an otherwise valid addition lacks Ledger support;
it is a provenance error only in `shadow`. A removed `must_do` or `can_skip=false`
activity remains a hard candidate failure regardless of its Ledger reason.

## Change control

### GLM structured-output boundary (2026-09-28)

The configured production model is `glm-5.3-flash` using BigModel Chat
Completions. GLM JSON Object mode receives the required JSON Schema as output
guidance; Pydantic and candidate business checks remain authoritative.

For the GLM Planner only, backend-owned UUID references are losslessly encoded
as request-local `ref_NNNN` tokens throughout structured input and schema enums.
The same request-local map restores exact identifiers before strict draft
parsing. Unknown tokens remain invalid; there is no fuzzy/name-based matching,
substitution of unknown places, or expansion of the allowed-place set. Dates,
sources, protected state, routes, goals and approval fences remain unchanged.
This is a provider wire-format adaptation, not a persistence/public API schema
change; existing checkpoints and revisions require no migration.

The existing single output-repair attempt now receives the previous visible
invalid output plus validation feedback. Hidden reasoning is never included or
stored. GLM responses are collected from the streaming API; only visible content,
the finish marker and usage are retained, never thinking deltas. A stream without
`stop`, and truncated/filtered Chat Completions, are incomplete even with text.
Tests: `test_planner_references.py`, `test_model_client.py` and
the unchanged candidate/approval regression suite.

Future Agent development must read this contract before changing schemas,
states, nodes, tools, permissions, or failure codes. Any contract change must be
delivered atomically with:

1. updated Pydantic and database constraints where applicable;
2. migration compatibility analysis;
3. unit or integration acceptance tests;
4. this document updated in the same change;
5. a passing isolated PostgreSQL backend suite.

Research, additional reviewer loops, cancellation, UI-selection persistence,
new intents, or automatic completion are contract changes, not incidental
implementation details.

### Agent Reliability Phase — Entity Resolution & Structured Output Stability (2026-09-28)

All Planner providers now use the same semantic output boundary, implemented in
`planner_entity_resolution.py`. Existing decisions require `source=existing` and
`activity_ref=activity_N`; new decisions require `source=candidate` and
`candidate_ref=candidate_N`. The mutually exclusive strict classes reject
cross-domain fields. Dynamic schema enums and the server resolver share one
request-local binding object. Unknown, protected or out-of-scope references are
not guessed. The resolver restores formal activity/place/source/cost identity
before route enrichment. Model output contains no database/provider UUID,
coordinates, route IDs, cost or derived before/after facts.

The internal context builder and persisted CandidatePlanSnapshot retain real
identifiers for authoritative validation/checkpoints. The provider prompt
contains each fact partition once, and bounded rejection summaries preserve
source Revision references while removing redundant compatibility aliases.
Trip/day/formal-version memory filtering and approval rules remain intact.

Shadow Ledger is no longer required in the model's main JSON Schema. If the
model supplies a Ledger, it is parsed/quarantined and the existing deterministic
Ledger validator still runs. An absent/invalid Ledger does not authorize model
reasons in Web. Stage 2.2 Decision Ledger MVP REMAINS OPEN. Enforced mode still
rejects missing/unverified Ledger; this phase does not claim its completion.

One structured-output repair remains the maximum. Syntax is parsed by Python
json without heuristic semantic repair; complete Markdown JSON fences are the
existing deterministic envelope normalization. Failure details carry
planner_schema_failure, planner_invalid_reference, planner_malformed_output,
planner_semantic_constraint_failure, provider_failure or
candidate_validation_failure. Web masks internal Planner contract errors and
retries the exact request in an independent PlanningRun.

No persistence schema/migration change is needed: the new short-reference
contract exists only at the model boundary. Existing saved revisions/checkpoints
continue to use CandidatePlanSnapshot and transactionally revalidate on accept.
The dedicated live eval is `python -m evals.agent_reliability.run`; it resets only
travel-decision-agent-demo, records 10 normal plus 10 Reject/Memory cycles, and
writes an independent artifact. Its live exit gate is separate from unit tests.


## Companion Travel Facts Integration v1 (2026-09-30 working tree)

The existing Companion graph has an additive, read-only FactToolPort for future
hourly forecasts. InformationNeed contains native FactRequirements; the tool
composes TravelFactService/freshness/authority and returns native ResolvedFacts.
Companion cannot call provider HTTP or write formal data. Stable Knowledge and
forecast server prose remain separate; model generation cannot fill weather gaps.
Weather and internal location freshness are configured explicitly; only fresh
resolved provider predictions can be shown. Current/past observations, alerts,
execution/route/opening/ticket/crowd facts and forecast-driven replanning remain
outside this Companion slice. Initial product supports Hangzhou/Nanjing city
representative WGS84 locations with IANA timezone and deterministic hour windows.
Foundation import is exact 5f9f5e5, not its snapshot parent. Runtime/Router/Brief
identity and Planning candidate/approval ownership are retained. This extension is deployed in API/worker after final live provider validation
and regression gates passed. Production smoke7/7 and formal state comparison pass.
Early network failures are retained as historical attempts; stale/unavailable
responses still cannot be promoted as verified forecasts. Evidence and limitations:
docs/agent/TRAVEL_FACTS_INTEGRATION_V1_20260930.md.


## Initial candidate editing boundary (2026-10-07 acceptance work)

An explicit day-level adjustment to the current session's pending initial
candidate may carry a backend-owned `trigger_snapshot.candidate_edit` reference.
The reference binds the exact revision ID and canonical snapshot hash; it is
not accepted from public request fields. Only same-trip, same-version, validated,
pending candidates on an awaiting-confirmation run qualify, while formal
activities remain empty. A source that changes, is decided, or becomes stale
fails closed. No arbitrary latest-trip history is selected.

`planning_context.candidate_edit_base` is separate draft-only context. The formal
`days`, intent entity grounding and Execution authority remain unchanged. The
Planner can select target-day candidates; places retained on other draft dates
are excluded from target-day choices. Backend preservation and Validator require
exact unchanged other-date candidate records. This narrowly permits those
verified preserved drafts outside the target day; every new or changed record
outside the target still fails scope validation. Routes, source ownership,
budget, date and version checks remain mandatory. Approval reloads the referenced
base before normal validation and formalization. Rejection changes no formal
state. This is an initial-candidate boundary, not general mutable history.

Compatibility: no public/Pydantic/database schema or migration change; existing
runs without the optional reference preserve current behavior. Evidence:
`tests/test_candidate_edit.py` plus graph/planner/run/assistant regression and
real browser `demo-lifecycle.spec.ts` (full three-day preservation required).
Production deployment remains pending full acceptance.


## Recovery route/budget projection alignment (2026-10-07 acceptance work)

Recovery enrichment now uses the same persisted execution frozen/protected
activity set as deterministic validation, including the current activity and
navigation target even while formal status remains planned. All candidates for in-progress or paused trips automatically enforce these
invariants from persisted execution status, including ordinary Planning requests.
Recovery/experience callers can also explicitly request the mode. Acceptance
rechecks the current execution state and retains the same protected activities. Implicit retention uses stable activity references in
route evidence. Candidate financial summaries include every implicitly retained
protected activity, including a pending navigation target, without charging
represented replacements twice. No public/DB schema or migration change.
Acceptance still revalidates and preserves executed activities; it does not
relax route completeness. Tests: test_recovery_route_enrichment.py, graph and
existing navigation/experience recovery regressions. Real failed Recovery and
incorrect210-versus240 cost evidence are preserved; full final rehearsal pending.
