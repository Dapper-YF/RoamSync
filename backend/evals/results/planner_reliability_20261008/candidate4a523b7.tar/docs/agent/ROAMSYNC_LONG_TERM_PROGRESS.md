# Current reliability checkpoint — 2026-10-08

Status: NOT READY. Original application8ee7dbf/documentation0b5010fe preserved. The human-approved six-path candidate is 26e33f7ecec848403c0992953c61216ddb305fec, branch codex/roamsync-planner-reliability-20261008; clean checkout E:/Study/RoamSync-planner-reliability-clean-20261008. Source6d0257506c8ae65cbfc640cbdbfd3376b23bac2cf9623306432513f48ddca1eb. Initial checkout was Git clean; later untracked browser evidence under backend/evals/results does not alter tracked source. API/Worker175 shipped files exactly match, no mounts; external provider configuration unchanged. Nginx3001/API8001 share isolated PG17; old failed Runs and Trips remain exactly preserved.

MEASURED: clean Git locked Backend/Worker/Web builds; empty PG17 migrations0→0034;858 passed/0fail/error/skip/2existing warnings. Web typecheck,125tests and build freshly passed. Bounded predefined real GLM6/6 completed/stop,0retries; strict Research2/2. This is a small sample, not an availability guarantee. Historical Research JSON raw completion/parse position and deeper transport origin remain UNLOCATED; separate categories, no guessed fix or provider replacement.

The new-ref normal browser exploration/facts/create preview/confirmation generated a valid nonempty8-activity Candidate: Trip58239cd8-b097-4898-870f-f49f1a98719d, Run5981caad-00b9-40ca-8d2f-671b4a92717b, Revision1e0c5bab-5d7d-45fc-bafe-6f7761112739. Validator valid=true/errors=[]; route schedule warning transparently recorded. UI visible, pending, formalactivities0/version1. Day2 edit Runbbea2a1a-e7f1-4bf6-bd6f-cc12ab8200a4 remains awaiting_clarification: generated “其他日期安排不变” is incorrectly treated as a missing activity. One normal UI supplement returns200 but retains the same ambiguity. This is a confirmed internal parser defect, independent of historical JSON/transport categories. Candidate Accept and Execution/Disruption/Recovery/Reject/Explanation have NOT passed on this candidate.

Independent follow-up proposal, NOT applied or committed: replace the exact equality with re.fullmatch(r"其他日期(?:安排)?不变", value), after real alias matching; add the observed form regression plus exact real-alias precedence and unknown venue negative checks. Five focused cases: old candidate1failed/4passed; patched5passed. Validator, Graph, route/time/budget, settings and explicit confirmation unchanged. Proposed source 3ae41a2daf9229933d1429fd9b2c58ff34a3564fb802f26a337b8c9d9faee52c; further source commit needs exact human authorization. Raw evidence/patch/manifests are excluded from Git in backend/evals/results/planner_reliability_20261008.

Production remains unchanged on8000/3000; no deployment/main merge/production migration/reset/Trip deletion. No RELEASE CANDIDATE READY claim. Next: approve the measured follow-up patch, create a new source identity and repeat affected clean locked regression/build/runtime binding and full real browser chain. After complete success only, request online approval. Future deployment plan: preserve current image IDs and external configuration; after explicit authorization take and verify DB backup, confirm production schema/readiness, resolve the automatic migration entrypoint separately, deploy API/Worker/Web together and perform read-only bindings. Rollback restores prior images/configuration while retaining PG volume and newer user records; no down migration/reset/restoration over newer data without separate authorization.

## Historical checkpoint preserved below

# RoamSync Long-Term Progress

## Goal

Stable trustworthy Goal-centric Travel Agent lifecycle: exploration, explicit Planning, validated Candidate, confirmation, execution, disruption/recovery and honest explanation/feedback. Goal ACTIVE; current release gate incomplete.

## Milestones / status / evidence

|Milestone|Status|Evidence|
|---|---|---|
|Companion / Router / Brief|DONE bounded|Prior Phase2.5 and release regression|
|Planning / confirmation authority|Prior bounded rehearsal verified; fresh clean-release real gate FAILED|Three failed actual Runs; no formal activity writes|
|Tourism Knowledge|DONE bounded / PARTIAL coverage|Frozen60 need34/60, assertions35/44, mixed7/10 unchanged|
|Travel Facts / Forecast|DONE bounded|Prior v1 plus second fresh conversation usable forecast|
|Opening Hours|DONE published-date-only|Second fresh conversation usable official dated facts; no regular/current-operation claim|
|Collector / Source Repair|PARTIAL / bounded slice closed|Official completeness NOT READY, no promotion|
|Repository reconstruction|VERIFIED source/build/regression|Approved366 files, three groups, clean checkout, locked Backend/Web/Worker builds|
|Clean-ref complete Demo|NOT READY|Real Provider research/json and transport failures; downstream chain unexecuted|
|Production reproducible deployment|PENDING / NOT AUTHORIZED|Production unchanged; final online decision after isolated gates|
|Decision Ledger2.2|OPEN|Honest missing-original-rationale fallback historically verified|
|Experience Learning|DEFERRED|No new learning/memory/provider/agent scope|

## Current slice / 2026-10-08

Git release preparation on codex/roamsync-demo-release-20261007 from main5572849. Human authorized exact grouping and approved363→366 dependency amendment. Backend fbd65f28f3fe5ee1ed99ba8182976a717c0018bc; Web93118dc6f1370c7be78e167ffb7adb640375573a; operator/docs application candidate8ee7dbf0ddc27fdb8fd55bc20fad9777ec4bf209. Final documentation-only checkpoint exact SHA in release_final_binding.json. Historical code is captured, not falsely attributed to this round. Unrelated dirty work retained; no destructive/history rewrite commands.

Clean source e7e22849869443bb73f96bce736fb86a1c4b3745f2a48f6f32da3273176622a6. Initial clean checkout366 hashes exact;175 API/Worker shipped source hashes exact, no source mounts; Web built Nginx on3001. Locked Linux full854 on newly migrated empty PG17, Web125/typecheck/build; controlled frozen Knowledge60 and holdout50 unchanged.

## Current blocker / actual acceptance

First live weather location query unavailable; recovered on second conversation. Explicit create succeeds. Initial research invalid JSON; two normal UI retries fail planner_unavailable; final Worker log RemoteProtocolError. Direct no-proxy model diagnostic fails APIConnectionError/ConnectError. Root upstream component attribution unproven. Fixture Trip version1, zero formal activities. Failed evidence retained; no mocked pass/relaxed assertion/old result substitution. Complete Candidate→Accept/Reject→Execution→Disruption→Recovery→Explanation still unverified on this release.

## Production / rollback

Accepted production source fc3a06ba… on API8000/Web3000 unchanged. Formal seven-table snapshot/Trip versions exact. Old images/configuration and PG volume recorded for future approved rollback. No deployment/main merge/production migration/data deletion. Do not run migration entrypoint against production without resolving separate DB authorization.

## Next selected work / release gates

Continue current acceptance after actual provider transport is stable; no new ordinary feature development. Rerun unchanged clean-ref lifecycle, inspect every Candidate/Validator/explicit decision, protect Execution state and verify Recovery costs, honest rationale and feedback. Compare final checkout/build/runtime manifests. Then report production differences and request final online approval. Repository Reproducibility and Demo Acceptance reports contain concrete deployment/rollback plan. Additional corpus/source promotion and Ledger2.2 redesign remain deferred.

## Historical context

Earlier dirty-tree isolated lifecycle passed versions1→2→3 and Recovery19000fen; current-version reject/feedback, city-scoped Knowledge/facts and honest Explanation passed targeted live checks. Older failed city/day/route/cost attempts remain historical evidence. These successes do not close the current clean-ref/production gates. Source Repair3-file bounded slice was PARTIAL; regular/exception NOT READY. Never claim full product completion based only on Git commits or unit tests.

Evidence: backend/evals/results/git_release_20261008 includes all audit/staged/commit manifests, full regression, clean source/runtime/images, failed browser attempts, production safety and release_final_binding.json. Raw artifacts excluded from Git; no Obsidian recording.
